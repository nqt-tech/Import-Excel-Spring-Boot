package net.sharecs.city.sharecsservice.core.abs;

public interface IDTO {
}
